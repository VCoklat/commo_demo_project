@extends('layout.master')

@section('title')
Home
@endsection
@section('topbar')
<!--==========================
Header
============================-->
<header id="header" class="fixed-top">
    <div class="container">

        <div class="logo float-left">
            <!-- Uncomment below if you prefer to use an image logo -->
            <!-- <h1 class="text-light"><a href="#header"><span>NewBiz</span></a></h1> -->
            <a href="#intro" class="scrollto"><img src="img/logo1.png" alt="" class="img-fluid"></a>
        </div>

        <nav class="main-nav float-right d-none d-lg-block">
            <ul>
                <li class="active"><a href="#intro">Home</a></li>
                <li><a href="#about">About Us</a></li>
                <li><a href="/portofolio">Portfolio</a></li>
                <li><a href="/services">Services</a></li>
                <li><a href="/news" class="btn-yellow">Commo News</a></li>
            </ul>
        </nav><!-- .main-nav -->

    </div>
</header><!-- #header -->
@endsection

@section('content')


<!--==========================
  Intro Section
============================-->
<section id="intro" class="clearfix">
    <div class="container">

        <!-- Floating Social Media bar Starts -->
        <div class="float-sm d-none d-sm-block">
            <div class="fl-fl float-fb">
                <i class="fa fa-facebook"></i>

            </div>
            <div class="fl-fl float-tw">
                <i class="fa fa-twitter"></i>

            </div>
            <div class="fl-fl float-gp">
                <i class="fa fa-google-plus"></i>

            </div>
            <div class="fl-fl float-rs">
                <i class="fa fa-rss"></i>
            </div>
            <div class="fl-fl float-ig">
                <i class="fa fa-instagram"></i>
            </div>
            <div class="fl-fl float-pn">
                <i class="fa fa-pinterest"></i>
            </div>
        </div>
        <!-- <div class="intro-img">
      <img src="img/intro-img.svg" alt="" class="img-fluid">
    </div> -->

        <div class="intro-info text-center col-12">
            @foreach($homes as $p)
            <h2>{{ $p->heading }} <br><span>{{ $p->textBold }}</span><br>{{ $p->heading2 }}</h2>
            <h5><span class="smallis"> 
                {{ $p->subheading }} </span> <br>{{ $p->subheading2 }}  </h5>
            <div>
            @endforeach


                <a href="#why-us" class="btn-get-started scrollto">Our Services</a>
        </div>


        </div>

    </div>
</section><!-- #intro -->

<main id="main">


    <!--==========================
    Services Section
  ============================-->
    <section id="about" class="">
        <div class="container rel">
            <img class="floating" src="img/bulet.png" alt="">

            <div class="row">
                <div class="col-md-5 col-12">
                    <h1 class="font-weight-bold big">About</h1>
                    @foreach($abouts as $s)
                    <p class="text-justify">{{ $s->content }}</p>
                    @endforeach
                </div>

                <div class="col-md-7 col-12  bigsize">
                    <div class="row">
                        <div class="col-md-2">
                            <span data-toggle="counter-up" class="big">50</span>
                            <div class="mt-">
                                <span>+</span>
                            </div>
                        </div>
                        <div class="col-md-8 ml-5 pl-5 pt-5 mt-4 mleft">
                            <h2>Our satisfied clients</h2>
                        </div>
                    </div>
                    <div class="row mt-4 z-index">
                        <div class="col-md-2">
                            <span data-toggle="counter-up" class="big">10</span>
                            <div class="mt-">
                                <span>+</span>
                            </div>
                        </div>
                        <div class="col-md-8 ml-5 pl-5 pt-5 mt-4 mleft">
                            <h3>Clients across countries</h3>
                        </div>
                    </div>
                    <img class="floating2" src="img/bulet.png" alt="">
                </div>
                <div class="col-md-12 mb-5 pb-5 z-index">
                    <img class="" width="100%" src="img/chart.png" alt="">
                </div>

                <div class="col-md-12 mt-4 text-center pd-5 mb-4 z-index">
                    <h1 class="font-weight-bold big">Why commo?</h1>
                </div>

                <div class="col-md-3 text-center z-index">
                    <img class="" width="150px" src="img/1.png" alt="">
                    <h4>We guarantee a quality</h4>
                </div>
                <div class="col-md-3 text-center z-index">
                    <img class="" width="150px" src="img/2.png" alt="">
                    <h4>on-time Delivery</h4>
                </div>
                <div class="col-md-3 text-center z-index">
                    <img class="" width="150px" src="img/w3.png" alt="">
                    <h4>Goal-Driven Team</h4>
                </div>
                <div class="col-md-3 text-center z-index">
                    <img class="" width="150px" src="img/w4.png" alt="">
                    <h4>Years of Creative experience</h4>
                </div>
                <img width="1050px" src="img/bullet2.png" class="floating3 d-none d-sm-block" alt="">
                <img width="" src="img/slice.png" class="z-index floating4">


            </div>
    </section>

    <!--==========================
    Why Us Section
  ============================-->

    <section id="why-us" class="wow fadeIn z-index">
        <div class="container">
            <header class="section-header text-center">
                <h1 class="font-weight-bold big text-white">Our Service?</h1>
            </header>
            <div class="row row-eq-height justify-content-center">
                <div class="col-md-4 col-12 pa-2 text-center">
                    <img class="" width="150px" src="img/services/a1.png" alt="">
                    <h4 class="text-white">Social Media Marketing</h4>
                </div>
                <div class="col-md-4 col-12 pa-2 text-center">
                    <img class="" width="150px" src="img/services/a2.png" alt="">
                    <h4 class="text-white">Photography Studio</h4>
                </div>
                <div class="col-md-4 col-12 pa-2 text-center">
                    <img class="" width="150px" src="img/services/a3.png" alt="">
                    <h4 class="text-white">Design Studio</h4>
                </div>
                <div class="col-md-4 col-12 pa-2 text-center">
                    <img class="" width="150px" src="img/services/a4.png" alt="">
                    <h4 class="text-white">Brand Campaign</h4>
                </div>
                <div class="col-md-4 col-12 pa-2 text-center">
                    <img class="" width="150px" src="img/services/a5.png" alt="">
                    <h4 class="text-white">Copy writing</h4>
                </div>
                <div class="col-md-4 col-12 pa-2 text-center">
                    <img class="" width="150px" src="img/services/a6.png" alt="">
                    <h4 class="text-white">Website Design</h4>
                </div>
            </div>
        </div>
    </section>


    <section id="new" class="clearfix pb-0">
        <div class="container">

            <header class="section-header">
                <h3 class="section-title">Our Happy Client</h3>
            </header>

            <img width="1050px" src="img/bulet.png" class="floating5 d-none d-sm-block" alt="">

            <div class="row justify-content-center">
                <div class="col-lg-8">

                    <div class="owl-carousel client-carousel wow fadeInUp">
                        <div class="client-item">
                            <img src="img/client/3.png" class="client-img" alt="">
                        </div>

                        <div class="client-item">
                            <img src="img/client/2.png" class="client-img" alt="">
                        </div>

                        <div class="client-item">
                            <img src="img/client/4.png" class="client-img" alt="">
                        </div>

                        <div class="client-item">
                            <img src="img/client/1.png" class="client-img" alt="">
                        </div>

                        <div class="client-item">
                            <img src="img/client/5.png" class="client-img" alt="">
                        </div>

                    </div>
                </div>
            </div>
            <img width="1050px" src="img/bulet.png" class="floating6 d-none d-sm-block" alt="">
            <img width="100%" src="img/slice2.png" class=" floatingabu">
        </div>
    </section><!-- #portfolio -->

    <!--==========================
    Clients Section
  ============================-->
    <section id="testimonials" class="section-bg2">
        <div class="container">

            <header class="section-header">
                <h3>What Client Say</h3>
            </header>
            <div class="row justify-content-center">
                <div class="col-lg-8">

                    <div class="owl-carousel testimonials-carousel wow fadeInUp">

                        <div class="testimonial-item">

                            <h3>Saul Goodman</h3>
                            <h4>Ceo &amp; Founder</h4>
                            <p>
                                Proin iaculis purus consequat sem cure digni ssim donec porttitora entum suscipit
                                rhoncus. Accusantium
                                quam, ultricies eget id, aliquam eget nibh et. Maecen aliquam, risus at semper.
                            </p>
                        </div>

                        <div class="testimonial-item">

                            <h3>Sara Wilsson</h3>
                            <h4>Designer</h4>
                            <p>
                                Export tempor illum tamen malis malis eram quae irure esse labore quem cillum quid
                                cillum eram malis
                                quorum velit fore eram velit sunt aliqua noster fugiat irure amet legam anim culpa.
                            </p>
                        </div>

                        <div class="testimonial-item">

                            <h3>Jena Karlis</h3>
                            <h4>Store Owner</h4>
                            <p>
                                Enim nisi quem export duis labore cillum quae magna enim sint quorum nulla quem veniam
                                duis minim
                                tempor labore quem eram duis noster aute amet eram fore quis sint minim.
                            </p>
                        </div>

                        <div class="testimonial-item">

                            <h3>Matt Brandon</h3>
                            <h4>Freelancer</h4>
                            <p>
                                Fugiat enim eram quae cillum dolore dolor amet nulla culpa multos export minim fugiat
                                minim velit
                                minim dolor enim duis veniam ipsum anim magna sunt elit fore quem dolore labore illum
                                veniam.
                            </p>
                        </div>

                        <div class="testimonial-item">

                            <h3>John Larson</h3>
                            <h4>Entrepreneur</h4>
                            <p>
                                Quis quorum aliqua sint quem legam fore sunt eram irure aliqua veniam tempor noster
                                veniam enim culpa
                                labore duis sunt culpa nulla illum cillum fugiat legam esse veniam culpa fore nisi
                                cillum quid.
                            </p>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section><!-- #testimonials -->

    <!--==========================
    Team Section
  ============================-->
    <section section id="portfolio" class="clearfix">
        <div class="container">

            <header class="section-header">
                <h3 class="section-title text-white">Our Portfolio</h3>
            </header>

            <div class="row">
                <div class="col-lg-12">
                    <ul id="portfolio-flters">
                        <li data-filter="*" class="filter-active">All</li>
                        <li data-filter=".filter-app">App</li>
                        <li data-filter=".filter-card">Card</li>
                        <li data-filter=".filter-web">Web</li>
                    </ul>
                </div>
            </div>

            <div class="row portfolio-container">

                <div class="col-lg-4 col-md-6 portfolio-item filter-app">
                    <div class="portfolio-wrap">
                        <img src="img/portfolio/app1.jpg" class="img-fluid" alt="">
                        <div class="portfolio-info">
                            <h4><a href="#">App 1</a></h4>
                            <p>App</p>
                            <div>
                                <a href="img/portfolio/app1.jpg" data-lightbox="portfolio" data-title="App 1"
                                    class="link-preview" title="Preview"><i class="ion ion-eye"></i></a>
                                <a href="#" class="link-details" title="More Details"><i
                                        class="ion ion-android-open"></i></a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 portfolio-item filter-web" data-wow-delay="0.1s">
                    <div class="portfolio-wrap">
                        <img src="img/portfolio/web3.jpg" class="img-fluid" alt="">
                        <div class="portfolio-info">
                            <h4><a href="#">Web 3</a></h4>
                            <p>Web</p>
                            <div>
                                <a href="img/portfolio/web3.jpg" class="link-preview" data-lightbox="portfolio"
                                    data-title="Web 3" title="Preview"><i class="ion ion-eye"></i></a>
                                <a href="#" class="link-details" title="More Details"><i
                                        class="ion ion-android-open"></i></a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 portfolio-item filter-app" data-wow-delay="0.2s">
                    <div class="portfolio-wrap">
                        <img src="img/portfolio/app2.jpg" class="img-fluid" alt="">
                        <div class="portfolio-info">
                            <h4><a href="#">App 2</a></h4>
                            <p>App</p>
                            <div>
                                <a href="img/portfolio/app2.jpg" class="link-preview" data-lightbox="portfolio"
                                    data-title="App 2" title="Preview"><i class="ion ion-eye"></i></a>
                                <a href="#" class="link-details" title="More Details"><i
                                        class="ion ion-android-open"></i></a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 portfolio-item filter-card">
                    <div class="portfolio-wrap">
                        <img src="img/portfolio/card2.jpg" class="img-fluid" alt="">
                        <div class="portfolio-info">
                            <h4><a href="#">Card 2</a></h4>
                            <p>Card</p>
                            <div>
                                <a href="img/portfolio/card2.jpg" class="link-preview" data-lightbox="portfolio"
                                    data-title="Card 2" title="Preview"><i class="ion ion-eye"></i></a>
                                <a href="#" class="link-details" title="More Details"><i
                                        class="ion ion-android-open"></i></a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 portfolio-item filter-web" data-wow-delay="0.1s">
                    <div class="portfolio-wrap">
                        <img src="img/portfolio/web2.jpg" class="img-fluid" alt="">
                        <div class="portfolio-info">
                            <h4><a href="#">Web 2</a></h4>
                            <p>Web</p>
                            <div>
                                <a href="img/portfolio/web2.jpg" class="link-preview" data-lightbox="portfolio"
                                    data-title="Web 2" title="Preview"><i class="ion ion-eye"></i></a>
                                <a href="#" class="link-details" title="More Details"><i
                                        class="ion ion-android-open"></i></a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 portfolio-item filter-app" data-wow-delay="0.2s">
                    <div class="portfolio-wrap">
                        <img src="img/portfolio/app3.jpg" class="img-fluid" alt="">
                        <div class="portfolio-info">
                            <h4><a href="#">App 3</a></h4>
                            <p>App</p>
                            <div>
                                <a href="img/portfolio/app3.jpg" class="link-preview" data-lightbox="portfolio"
                                    data-title="App 3" title="Preview"><i class="ion ion-eye"></i></a>
                                <a href="#" class="link-details" title="More Details"><i
                                        class="ion ion-android-open"></i></a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 portfolio-item filter-card">
                    <div class="portfolio-wrap">
                        <img src="img/portfolio/card1.jpg" class="img-fluid" alt="">
                        <div class="portfolio-info">
                            <h4><a href="#">Card 1</a></h4>
                            <p>Card</p>
                            <div>
                                <a href="img/portfolio/card1.jpg" class="link-preview" data-lightbox="portfolio"
                                    data-title="Card 1" title="Preview"><i class="ion ion-eye"></i></a>
                                <a href="#" class="link-details" title="More Details"><i
                                        class="ion ion-android-open"></i></a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 portfolio-item filter-card" data-wow-delay="0.1s">
                    <div class="portfolio-wrap">
                        <img src="img/portfolio/card3.jpg" class="img-fluid" alt="">
                        <div class="portfolio-info">
                            <h4><a href="#">Card 3</a></h4>
                            <p>Card</p>
                            <div>
                                <a href="img/portfolio/card3.jpg" class="link-preview" data-lightbox="portfolio"
                                    data-title="Card 3" title="Preview"><i class="ion ion-eye"></i></a>
                                <a href="#" class="link-details" title="More Details"><i
                                        class="ion ion-android-open"></i></a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 portfolio-item filter-web" data-wow-delay="0.2s">
                    <div class="portfolio-wrap">
                        <img src="img/portfolio/web1.jpg" class="img-fluid" alt="">
                        <div class="portfolio-info">
                            <h4><a href="#">Web 1</a></h4>
                            <p>Web</p>
                            <div>
                                <a href="img/portfolio/web1.jpg" class="link-preview" data-lightbox="portfolio"
                                    data-title="Web 1" title="Preview"><i class="ion ion-eye"></i></a>
                                <a href="#" class="link-details" title="More Details"><i
                                        class="ion ion-android-open"></i></a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="row">
                <div class="col-md-12 text-center">
                    <a type="button" class="btn btn-outline-warning" href="/portofolio">Show More</a>
                </div>
            </div>


        </div>
    </section><!-- #team -->

    <!--==========================
    Clients Section
  ============================-->
    <section id="clients" class="section-yellow">

        <div class="container">



            <div class="row">
                <div class="col-md-3">
                    <h1 class="font-weight-bold big">Commo News</h1>
                </div>
                <div class="col-md-9">

                    <div class="row pl-4">
                        <div class="col-md-12 mb-4">
                            <div class="container">
                                <div class="row fontbig bordering">
                                    <div class="col-md-3 col-12  pt-2">
                                        <span class="font-weight-bold ">Categories</span>
                                    </div>
                                    <div class="col-md-9 col-12 text-left pt-2">
                                        <ul class="list-inline">
                                            <li class="list-inline-item font-weight-bold mr-5">All</li>
                                            <li class="mr-5 list-inline-item">Digital</li>
                                            <li class="mr-5 list-inline-item">Creative</li>
                                            <li class="mr-5 list-inline-item">Lifestyle</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card mb-4 box-shadow">
                                <img class="card-img-top"
                                    data-src="holder.js/100px225?theme=thumb&amp;bg=55595c&amp;fg=eceeef&amp;text=Thumbnail"
                                    alt="Thumbnail [100%x225]" style="height: 200px; width: 100%; display: block;"
                                    src="data:image/svg+xml;charset=UTF-8,%3Csvg%20width%3D%22348%22%20height%3D%22225%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20348%20225%22%20preserveAspectRatio%3D%22none%22%3E%3Cdefs%3E%3Cstyle%20type%3D%22text%2Fcss%22%3E%23holder_16f4ff660d8%20text%20%7B%20fill%3A%23eceeef%3Bfont-weight%3Abold%3Bfont-family%3AArial%2C%20Helvetica%2C%20Open%20Sans%2C%20sans-serif%2C%20monospace%3Bfont-size%3A17pt%20%7D%20%3C%2Fstyle%3E%3C%2Fdefs%3E%3Cg%20id%3D%22holder_16f4ff660d8%22%3E%3Crect%20width%3D%22348%22%20height%3D%22225%22%20fill%3D%22%2355595c%22%3E%3C%2Frect%3E%3Cg%3E%3Ctext%20x%3D%22116.70000076293945%22%20y%3D%22120.3%22%3EThumbnail%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fsvg%3E"
                                    data-holder-rendered="true">
                                <div class="card-body">
                                    <p class="card-text">This is a wider card with supporting text below as a natural
                                        lead-in to additional content. </p>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-outline-warning2">Read</button>

                                        </div>
                                        <small class="text-muted">9 mins</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card mb-4 box-shadow">
                                <img class="card-img-top"
                                    data-src="holder.js/100px225?theme=thumb&amp;bg=55595c&amp;fg=eceeef&amp;text=Thumbnail"
                                    alt="Thumbnail [100%x225]" style="height: 200px; width: 100%; display: block;"
                                    src="data:image/svg+xml;charset=UTF-8,%3Csvg%20width%3D%22348%22%20height%3D%22225%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20348%20225%22%20preserveAspectRatio%3D%22none%22%3E%3Cdefs%3E%3Cstyle%20type%3D%22text%2Fcss%22%3E%23holder_16f4ff660de%20text%20%7B%20fill%3A%23eceeef%3Bfont-weight%3Abold%3Bfont-family%3AArial%2C%20Helvetica%2C%20Open%20Sans%2C%20sans-serif%2C%20monospace%3Bfont-size%3A17pt%20%7D%20%3C%2Fstyle%3E%3C%2Fdefs%3E%3Cg%20id%3D%22holder_16f4ff660de%22%3E%3Crect%20width%3D%22348%22%20height%3D%22225%22%20fill%3D%22%2355595c%22%3E%3C%2Frect%3E%3Cg%3E%3Ctext%20x%3D%22116.70000076293945%22%20y%3D%22120.3%22%3EThumbnail%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fsvg%3E"
                                    data-holder-rendered="true">
                                <div class="card-body">
                                    <p class="card-text">This is a wider card with supporting text below as a natural
                                        lead-in to additional content. </p>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-outline-warning2">Read</button>

                                        </div>
                                        <small class="text-muted">9 mins</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card mb-4 box-shadow">
                                <img class="card-img-top"
                                    data-src="holder.js/100px225?theme=thumb&amp;bg=55595c&amp;fg=eceeef&amp;text=Thumbnail"
                                    alt="Thumbnail [100%x225]" style="height: 200px; width: 100%; display: block;"
                                    src="data:image/svg+xml;charset=UTF-8,%3Csvg%20width%3D%22348%22%20height%3D%22225%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20348%20225%22%20preserveAspectRatio%3D%22none%22%3E%3Cdefs%3E%3Cstyle%20type%3D%22text%2Fcss%22%3E%23holder_16f4ff660e3%20text%20%7B%20fill%3A%23eceeef%3Bfont-weight%3Abold%3Bfont-family%3AArial%2C%20Helvetica%2C%20Open%20Sans%2C%20sans-serif%2C%20monospace%3Bfont-size%3A17pt%20%7D%20%3C%2Fstyle%3E%3C%2Fdefs%3E%3Cg%20id%3D%22holder_16f4ff660e3%22%3E%3Crect%20width%3D%22348%22%20height%3D%22225%22%20fill%3D%22%2355595c%22%3E%3C%2Frect%3E%3Cg%3E%3Ctext%20x%3D%22116.70000076293945%22%20y%3D%22120.3%22%3EThumbnail%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fsvg%3E"
                                    data-holder-rendered="true">
                                <div class="card-body">
                                    <p class="card-text">This is a wider card with supporting text below as a natural
                                        lead-in to additional content. </p>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-outline-warning2">Read</button>

                                        </div>
                                        <small class="text-muted">9 mins</small>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                <div class="col-md-3">
                    <h1 class="font-weight-bold big">Watch Us</h1>
                </div>
                <div class="col-md-9">
                    <div class="row pl-4">

                      <div class="col-md-12">
                        <div class="container mb-4">
                          <div class="row fontbig bordering">
                              <div class="col-md-3 col-12  pt-2">
                                  <span class="font-weight-bold ">Categories</span>
                              </div>
                              <div class="col-md-9 col-12 text-left pt-2">
                                  <ul class="list-inline">
                                      <li class="list-inline-item font-weight-bold mr-5">All</li>
                                      <li class="mr-5 list-inline-item">Digital</li>
                                      <li class="mr-5 list-inline-item">Creative</li>
                                      <li class="mr-5 list-inline-item">Lifestyle</li>
                                  </ul>
                              </div>
                          </div>
                      </div>
                      </div>

                        <div class="col-md-4">
                            <div class="card mb-4 box-shadow">
                                <img class="card-img-top"
                                    data-src="holder.js/100px225?theme=thumb&amp;bg=55595c&amp;fg=eceeef&amp;text=Thumbnail"
                                    alt="Thumbnail [100%x225]" style="height: 200px; width: 100%; display: block;"
                                    src="data:image/svg+xml;charset=UTF-8,%3Csvg%20width%3D%22348%22%20height%3D%22225%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20348%20225%22%20preserveAspectRatio%3D%22none%22%3E%3Cdefs%3E%3Cstyle%20type%3D%22text%2Fcss%22%3E%23holder_16f4ff660d8%20text%20%7B%20fill%3A%23eceeef%3Bfont-weight%3Abold%3Bfont-family%3AArial%2C%20Helvetica%2C%20Open%20Sans%2C%20sans-serif%2C%20monospace%3Bfont-size%3A17pt%20%7D%20%3C%2Fstyle%3E%3C%2Fdefs%3E%3Cg%20id%3D%22holder_16f4ff660d8%22%3E%3Crect%20width%3D%22348%22%20height%3D%22225%22%20fill%3D%22%2355595c%22%3E%3C%2Frect%3E%3Cg%3E%3Ctext%20x%3D%22116.70000076293945%22%20y%3D%22120.3%22%3EThumbnail%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fsvg%3E"
                                    data-holder-rendered="true">
                                <div class="card-body">
                                    <p class="card-text">This is a wider card with supporting text below as a natural
                                        lead-in to additional content. </p>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-outline-warning2">Read</button>

                                        </div>
                                        <small class="text-muted">9 mins</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card mb-4 box-shadow">
                                <img class="card-img-top"
                                    data-src="holder.js/100px225?theme=thumb&amp;bg=55595c&amp;fg=eceeef&amp;text=Thumbnail"
                                    alt="Thumbnail [100%x225]" style="height: 200px; width: 100%; display: block;"
                                    src="data:image/svg+xml;charset=UTF-8,%3Csvg%20width%3D%22348%22%20height%3D%22225%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20348%20225%22%20preserveAspectRatio%3D%22none%22%3E%3Cdefs%3E%3Cstyle%20type%3D%22text%2Fcss%22%3E%23holder_16f4ff660de%20text%20%7B%20fill%3A%23eceeef%3Bfont-weight%3Abold%3Bfont-family%3AArial%2C%20Helvetica%2C%20Open%20Sans%2C%20sans-serif%2C%20monospace%3Bfont-size%3A17pt%20%7D%20%3C%2Fstyle%3E%3C%2Fdefs%3E%3Cg%20id%3D%22holder_16f4ff660de%22%3E%3Crect%20width%3D%22348%22%20height%3D%22225%22%20fill%3D%22%2355595c%22%3E%3C%2Frect%3E%3Cg%3E%3Ctext%20x%3D%22116.70000076293945%22%20y%3D%22120.3%22%3EThumbnail%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fsvg%3E"
                                    data-holder-rendered="true">
                                <div class="card-body">
                                    <p class="card-text">This is a wider card with supporting text below as a natural
                                        lead-in to additional content. </p>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-outline-warning2">Read</button>

                                        </div>
                                        <small class="text-muted">9 mins</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card mb-4 box-shadow">
                                <img class="card-img-top"
                                    data-src="holder.js/100px225?theme=thumb&amp;bg=55595c&amp;fg=eceeef&amp;text=Thumbnail"
                                    alt="Thumbnail [100%x225]" style="height: 200px; width: 100%; display: block;"
                                    src="data:image/svg+xml;charset=UTF-8,%3Csvg%20width%3D%22348%22%20height%3D%22225%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20348%20225%22%20preserveAspectRatio%3D%22none%22%3E%3Cdefs%3E%3Cstyle%20type%3D%22text%2Fcss%22%3E%23holder_16f4ff660e3%20text%20%7B%20fill%3A%23eceeef%3Bfont-weight%3Abold%3Bfont-family%3AArial%2C%20Helvetica%2C%20Open%20Sans%2C%20sans-serif%2C%20monospace%3Bfont-size%3A17pt%20%7D%20%3C%2Fstyle%3E%3C%2Fdefs%3E%3Cg%20id%3D%22holder_16f4ff660e3%22%3E%3Crect%20width%3D%22348%22%20height%3D%22225%22%20fill%3D%22%2355595c%22%3E%3C%2Frect%3E%3Cg%3E%3Ctext%20x%3D%22116.70000076293945%22%20y%3D%22120.3%22%3EThumbnail%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fsvg%3E"
                                    data-holder-rendered="true">
                                <div class="card-body">
                                    <p class="card-text">This is a wider card with supporting text below as a natural
                                        lead-in to additional content. </p>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-outline-warning2">Read</button>

                                        </div>
                                        <small class="text-muted">9 mins</small>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        </div>

    </section>

    <!--==========================
    Contact Section
  ============================-->
    <section id="contact">
        <div class="container">


            <div class="row wow fadeInUp">

                <div class="col-md-3">
                    <div class="map mb-4 mb-lg-0">
                        <h1 class="font-weight-bold big text-white">Reach</h1>
                    </div>
                </div>

                <div class="col-md-9 ">


                    <div class="form">
                        <div id="sendmessage">Your message has been sent. Thank you!</div>
                        <div id="errormessage"></div>
                        <form action="" method="post" role="form" class="contactForm">
                            <div class="form-row">
                                <div class="form-group col-lg-6">
                                    <input type="text" name="name" class="form-control" id="name"
                                        placeholder="Your Name" data-rule="minlen:4"
                                        data-msg="Please enter at least 4 chars" />
                                    <div class="validation"></div>
                                </div>
                                <div class="form-group col-lg-6">
                                    <input type="email" class="form-control" name="email" id="email"
                                        placeholder="Your Email" data-rule="email"
                                        data-msg="Please enter a valid email" />
                                    <div class="validation"></div>
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" name="subject" id="subject"
                                    placeholder="Subject" data-rule="minlen:4"
                                    data-msg="Please enter at least 8 chars of subject" />
                                <div class="validation"></div>
                            </div>
                            <div class="form-group">
                                <textarea class="form-control" name="message" rows="5" data-rule="required"
                                    data-msg="Please write something for us" placeholder="Message"></textarea>
                                <div class="validation"></div>
                            </div>
                            <div class="text-left"><button type="submit" title="Send Message"
                                    class="btn btn-outline-warning">Send Message</button></div>
                        </form>
                    </div>
                </div>

            </div>

        </div>
    </section><!-- #contact -->

</main>

@endsection
