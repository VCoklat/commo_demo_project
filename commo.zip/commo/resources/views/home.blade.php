@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                </div>

                <table border="1">
                    <tr>
                        <th>heading</th>
                        <th>Bold</th>
                        <th>Heading2</th>
                        <th>Sub heading</th>
                        <th>Sub heading2</th>
                    </tr>
                    @foreach($homes as $p)
                    <tr>
                        <td>{{ $p->heading }}</td>
                        <td>{{ $p->textBold }}</td>
                        <td>{{ $p->heading2 }}</td>
                        <td>{{ $p->subheading }}</td>
                        <td>{{ $p->subheading2 }}</td>
                    </tr>
                    @endforeach
                </table>
             
            </div>
        </div>
    </div>
</div>
@endsection
