@extends('admin.layout')

@section('home')

@endsection

@section('content')

<div class="container-fluid">
  <div class="row">
      <div class="col-md-12">
          <div class="card">
              <div class="header">
                  <h4 class="title">Portofolio </h4>
              </div>
              <div class="content pa-4">
                @if(count($errors) > 0)
				<div class="alert alert-danger">
					@foreach ($errors->all() as $error)
					{{ $error }} <br/>
					@endforeach
				</div>
				@endif
            <div class="pa-5">
				<form action="/adminportofolio/proses" method="POST" enctype="multipart/form-data">
					{{ csrf_field() }}
 
					<div class="form-group">
						<b>File Gambar</b><br/>
						<input type="file" name="file">
					</div>
 
					<div class="form-group">
						<b>Title</b>
						<input type="text" class="form-control" name="title">
                    </div>
                    
                    <div class="form-group">
						<b>Description</b>
						<textarea class="form-control" name="content"></textarea>
					</div>
 
					<input type="submit" value="Upload" class="btn btn-primary pb-4">
                </form>
            </div>
                
                <table class="table table-bordered table-striped mt-5">
					<thead>
						<tr>
							<th width="1%">File</th>
                            <th>Title</th>
                            <th>Description</th>
							<th width="1%">action</th>
						</tr>
					</thead>
					<tbody>
						@foreach($portofolio as $g)
						<tr>
							<td><img width="150px" src="{{ url('/image_upload/'.$g->file) }}"></td>
                            <td>{{$g->title}}</td>
                            <td>{{$g->content}}</td>
							<td><a class="btn btn-danger" href="/upload/hapus/{{ $g->id }}">HAPUS</a></td>
						</tr>
						@endforeach
					</tbody>
				</table>
              </div>
          </div>
      </div>
  </div>


</div>
    <!-- End of Main Content -->
@endsection