@extends('admin.layout')

@section('home')

@endsection

@section('content')

<div class="container-fluid">
  <div class="row">
      <div class="col-md-12">
          <div class="card">
              <div class="header">
                  <h4 class="title">About Edit</h4>
              </div>
              <div class="content">
                @foreach($abouts as $p)
                            <form action="/adminabout/update" method="post">
                                {{ csrf_field() }}
                                <input type="hidden" name="id" value="{{ $p->id }}"> <br />

                                <div class="form-group row">
                                    
                                    <div class="col-sm-12">
                                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="15" name="content" height="950px">{{ $p->content }}</textarea>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 col-xs-6">
                                        <a href="/adminabout"  class="btn btn-warning">cancel</a>
                                    </div>
                                    <div class="col-md-6  col-xs-6 text-right">
                                        <button  type="submit" class="btn btn-info text-right mb-2">save</button>
                                    </div>
                                </div>
                            
                               

                            </form>
                            @endforeach
              </div>
          </div>
      </div>
  </div>



</div>
    <!-- End of Main Content -->
@endsection