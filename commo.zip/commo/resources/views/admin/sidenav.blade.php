<div class="sidebar" data-color="blue" data-image="template/img/sidebar-5.jpg">


    <div class="sidebar-wrapper">
          <div class="logo">
              <a href="/adminlte" class="simple-text">
                <img src="{{asset('img/logo1.png')}}" alt="" width="200px">
              </a>
          </div>

          <ul class="nav">
              <li class="{{ Request::route()->getName() == 'dashboard' ? ' active' : '' }}">
                  <a href="/adminlte">
                      <i class="pe-7s-graph"></i>
                      <p>Dashboard</p>
                  </a>
              </li>
              <li class="{{ Request::route()->getName() == 'about' ? ' active' : '' }}">
                  <a href="/adminabout">
                      <i class="pe-7s-help2"></i>
                      <p>about</p>
                  </a>
              </li>
              <li class="{{ Request::route()->getName() == 'portofolio' ? ' active' : '' }}">
                  <a href="/adminportofolio">
                      <i class="pe-7s-photo"></i>
                      <p>portofolio</p>
                  </a>
              </li>
          </ul>
    </div>
  </div>