@extends('admin.layout')

@section('home')

@endsection

@section('content')

<div class="container-fluid">
  <div class="row">
      <div class="col-md-12">
          <div class="card">
              <div class="header">
                  <h4 class="title">Home </h4>
              </div>
              <div class="content table-responsive table-full-width">
                <table class="table table-hover table-striped" >
                  <tr>
                      <th>heading</th>
                      <th>Bold</th>
                      <th>Heading2</th>
                      <th>Sub heading</th>
                      <th>Sub heading2</th>
                      <th>Action</th>
                  </tr>
                  @foreach($homes as $p)
                  <tr>
                      <td>{{ $p->heading }}</td>
                      <td>{{ $p->textBold }}</td>
                      <td>{{ $p->heading2 }}</td>
                      <td>{{ $p->subheading }}</td>
                      <td>{{ $p->subheading2 }}</td>
                  <td><a href="/adminlte/edit/{{ $p->id}}" type="button" class="btn btn-info">Edit</a></td>
                  </tr>
                  @endforeach
              </table>
              </div>
          </div>
      </div>
  </div>


</div>
    <!-- End of Main Content -->
@endsection