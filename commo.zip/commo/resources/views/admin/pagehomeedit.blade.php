@extends('admin.layout')

@section('home')

@endsection

@section('content')

<div class="container-fluid">
  <div class="row">
      <div class="col-md-12">
          <div class="card">
              <div class="header">
                  <h4 class="title">Home</h4>
              </div>
              <div class="content">
                @foreach($homes as $p)
                            <form action="/homes/update" method="post">
                                {{ csrf_field() }}
                                <input type="hidden" name="id" value="{{ $p->id }}"> <br />

                                <div class="form-group row">
                                    <label for="staticEmail" class="col-sm-2 col-form-label">Heading</label>
                                    <div class="col-sm-10">
                                        <input type="text" required="required" class="form-control" name="heading"
                                            value="{{ $p->heading }}">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="staticEmail" class="col-sm-2 col-form-label">Bold Text</label>
                                    <div class="col-sm-10">
                                        <input type="text" required="required" class="form-control" name="textBold"
                                            value="{{ $p->textBold }}">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="staticEmail" class="col-sm-2 col-form-label">Heading2</label>
                                    <div class="col-sm-10">
                                        <input type="text" required="required" class="form-control" name="heading2"
                                            value="{{ $p->heading2 }}">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="staticEmail" class="col-sm-2 col-form-label">subheading</label>
                                    <div class="col-sm-10">
                                        <input type="text" required="required" class="form-control" name="subheading"
                                            value="{{ $p->subheading }}">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="staticEmail" class="col-sm-2 col-form-label">subheading2</label>
                                    <div class="col-sm-10">
                                        <input type="text" required="required" class="form-control" name="subheading2"
                                            value="{{ $p->subheading2 }}">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 col-xs-6">
                                        <a href="/adminlte"  class="btn btn-warning">cancel</a>
                                    </div>
                                    <div class="col-md-6  col-xs-6 text-right">
                                        <button  type="submit" class="btn btn-info text-right mb-2">save</button>
                                    </div>
                                </div>
                            
                               

                            </form>
                            @endforeach
              </div>
          </div>
      </div>
  </div>



</div>
    <!-- End of Main Content -->
@endsection