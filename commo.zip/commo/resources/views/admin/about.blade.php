@extends('admin.layout')

@section('home')

@endsection

@section('content')

<div class="container-fluid">
  <div class="row">
      <div class="col-md-12">
          <div class="card">
              <div class="header">
                  <h4 class="title">About </h4>
              </div>
              <div class="content table-responsive table-full-width">
                <table class="table table-hover table-striped" >
                  <tr>
                      <th>About</th>
                      <th>Action</th>
                  </tr>
                  @foreach($abouts as $p)
                  <tr>
                  <td>{{ $p->content }}</td>
                  <td><a href="/adminabout/edit/{{ $p->id}}" type="button" class="btn btn-info">Edit</a></td>
                  </tr>
                  @endforeach
              </table>
              </div>
          </div>
      </div>
  </div>


</div>
    <!-- End of Main Content -->
@endsection