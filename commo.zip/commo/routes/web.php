<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'PhomeController@index');

Route::get('/portofolio', function () {
    return view('page.portofolio');
});

Route::get('/news', function () {
    return view('page.news');
});

Route::get('/services', function () {
    return view('page.service');
});
Route::get('/services-post', function () {
    return view('page.servicepost');
});


Auth::routes();

Route::get('/adminlte', 'HomeController@index')->name('dashboard');
Route::get('/adminabout', 'AboutController@index')->name('about');
Route::get('/adminlte/edit/{id}', 'HomeController@edit')->name('dashboard');
Route::get('/adminabout/edit/{id}', 'AboutController@edit')->name('about');

Route::post('/homes/update','HomeController@update')->name('dashboar');
Route::post('/adminabout/update', 'AboutController@update')->name('about');

Route::get('/adminportofolio', 'UploadController@upload')->name('portofolio');
Route::post('/adminportofolio/proses', 'UploadController@proses_upload')->name('portofolio');
Route::get('/upload/hapus/{id}', 'UploadController@delete')->name('portofolio');


