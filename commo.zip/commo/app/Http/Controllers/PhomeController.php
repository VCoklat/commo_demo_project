<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PhomeController extends Controller
{
    public function index()
    {
        $homes = DB::table('homes')->get();
        $abouts = DB::table('abouts')->get();
        return view('page.home',['homes' => $homes,'abouts' => $abouts]);
        
    }
}
