<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\portofolio;
use File;
 
class UploadController extends Controller
{
	public function upload(){
        $portofolio = portofolio::get();
		return view('admin.upload',['portofolio' => $portofolio]);
		
	}
 
	public function proses_upload(Request $request){
		$this->validate($request, [
			'file' => 'required|file|image|mimes:jpeg,png,jpg|max:2048',
        'title' => 'required',
        'content' => 'required',
		]);
 
        $file = $request->file('file');
 
        $nama_file = time()."_".$file->getClientOriginalName();
     
              // isi dengan nama folder tempat kemana file diupload
        $tujuan_upload = 'image_upload';
        $file->move($tujuan_upload,$nama_file);

        portofolio::create([
			'file' => $nama_file,
            'title' => $request->title,
            'content' => $request->content
        ]);
        return redirect()->back();
    }
    public function delete($id)
{
    	// hapus file
	$portofolio = portofolio::where('id',$id)->first();
	File::delete('image_upload/'.$portofolio->file);
 
	// hapus data
	portofolio::where('id',$id)->delete();
 
	return redirect()->back();
}
}
