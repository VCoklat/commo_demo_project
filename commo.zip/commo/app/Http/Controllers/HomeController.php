<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $homes = DB::table('homes')->get();
    	return view('admin.dashboard',['homes' => $homes]);
    }
    public function edit($id)
    {
        $homes = DB::table('homes')->where('id',$id)->get();
    	return view('admin.pagehomeedit',['homes' => $homes]);
    }

    public function update(Request $request)
    {
        DB::table('homes')->where('id',$request->id)->update([
            'heading' => $request->heading,
            'textBold' => $request->textBold,
            'heading2' => $request->heading2,
            'subheading' => $request->subheading,
            'subheading2' => $request->subheading2
        ]);
        	// alihkan halaman ke halaman pegawai
	        return redirect('/adminlte');
    }

  
}
