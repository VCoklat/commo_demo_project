<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AboutController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $abouts = DB::table('abouts')->get();
    	return view('admin.about',['abouts' => $abouts]);
    }

    public function edit($id)
    {
        $abouts = DB::table('abouts')->where('id',$id)->get();
    	return view('admin.aboutedit',['abouts' => $abouts]);
    }

    public function update(Request $request)
    {
        DB::table('abouts')->where('id',$request->id)->update([
            'content' => $request->content
        ]);
        	// alihkan halaman ke halaman pegawai
	        return redirect('/adminabout');
    }

}
