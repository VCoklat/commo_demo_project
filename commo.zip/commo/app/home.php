<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class home extends Model
{
   protected $fillable = ['heading', 'textBold','heading2', 'subheading,','subheading2'];
}
